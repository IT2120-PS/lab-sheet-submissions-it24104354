setwd("C:/Users/minol/OneDrive - Sri Lanka Institute of Information Technology/Desktop/it24104354lab08")
getwd()
#question 1

#1.1
baking_times <-rnorm(25,mean=45,sd=2)

#1.2
t.test(baking_times,mu=46,alternative="less")