setwd("C:/Users/minol/OneDrive/Desktop/IT24104354Lab5")
company_data <- read.csv("Data.txt")
shareholders <- company_data$Number_of_Shareholders.thousands.
#Basic histogram
hist(shareholders, main="Histogram of Shareholders", xlab="Shareholders (in thousands)", col="skyblue", border="black")
#histogram with 7 classes
breaks_seq <- seq(130, 270, length.out=8)  # 7 classes -> 8 breakpoints
hist(shareholders, breaks=breaks_seq, main="Histogram (7 Classes)", xlab="Shareholders (in thousands)", col="lightgreen", border="black")
# 3. Frequency Distribution
freq_table <- table(cut(shareholders, breaks=breaks_seq, right=FALSE))
print(freq_table)
# 4. Frequency Polygon
plot(freq_table, type="o", col="blue", main="Frequency Polygon", xlab="Shareholder Classes", ylab="Frequency")

#  Cumulative Frequency Polygon (Ogive)
cum_freq <- cumsum(freq_table)
plot(cum_freq, type="o", col="red", main="Cumulative Frequency Polygon (Ogive)", xlab="Shareholder Classes", ylab="Cumulative Frequency")

# Load Delivery Times data
delivery_data <- read.table("Exercise - Lab 05.txt", header = TRUE, check.names = FALSE)
Delivery_Times <- delivery_data[["Delivery_Time_(minutes)"]]

# 1. Histogram with 9 class intervals (20 to 70, right-open)
breaks_delivery <- seq(20, 70, length.out=10) # 9 intervals -> 10 breakpoints
hist(Delivery_Times, breaks=breaks_delivery, right=FALSE,
     main="Histogram of Delivery Times", xlab="Delivery Time (minutes)", col="orange", border="black")

# 2. Comment: Check shape -> skewness/normal
summary(Delivery_Times)

# 3. Cumulative Frequency Polygon (Ogive)
freq_delivery <- table(cut(Delivery_Times, breaks=breaks_delivery, right=FALSE))
cum_freq_delivery <- cumsum(freq_delivery)
plot(cum_freq_delivery, type="o", col="purple", main="Cumulative Frequency Polygon (Ogive)", xlab="Delivery Time Classes", ylab="Cumulative Frequency")
