setwd("C:\\Users\\minol\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24104354PSLab6")
### Question 1 ###
n <- 50
p <- 0.85

# (i) Distribution: Binomial(n=50, p=0.85)
# (ii) Probability at least 47 passed
p_ge47 <- 1 - pbinom(46, size = n, prob = p)
p_ge47

### Question 2 ###
lambda <- 12

# (i) Random variable: Number of calls in an hour
# (ii) Distribution: Poisson(lambda=12)
# (iii) Probability exactly 15 calls
p_eq15 <- dpois(15, lambda)
p_eq15
